import React, { InputHTMLAttributes } from 'react';
import { AlertCircle } from 'lucide-react';

interface FormCheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: string;
  error?: string;
  helperText?: string;
}

const FormCheckbox: React.FC<FormCheckboxProps> = ({
  label,
  error,
  helperText,
  className = '',
  ...props
}) => {
  return (
    <div className="flex items-start">
      <div className="flex items-center h-5">
        <input
          type="checkbox"
          {...props}
          className={`
            h-4 w-4 rounded
            ${error
              ? 'border-red-300 text-red-600 focus:ring-red-500'
              : 'border-gray-300 text-indigo-600 focus:ring-indigo-500'
            }
            ${props.disabled ? 'bg-gray-100' : 'bg-white'}
            transition-colors duration-200
            ${className}
          `}
        />
      </div>
      <div className="ml-3 text-sm">
        <label
          htmlFor={props.id}
          className={`font-medium ${props.disabled ? 'text-gray-500' : 'text-gray-700'}`}
        >
          {label}
        </label>
        {error && (
          <div className="mt-1 flex items-center text-sm text-red-600">
            <AlertCircle className="h-4 w-4 mr-1" />
            {error}
          </div>
        )}
        {helperText && !error && (
          <p className="text-gray-500">{helperText}</p>
        )}
      </div>
    </div>
  );
};

export default FormCheckbox;