import React from 'react';
import { ResponsiveSankey } from '@nivo/sankey';

interface SankeyChartProps {
  data: {
    nodes: Array<{
      id: string;
      color?: string;
    }>;
    links: Array<{
      source: string;
      target: string;
      value: number;
    }>;
  };
}

const defaultMargin = { top: 40, right: 160, bottom: 40, left: 50 };
const defaultTheme = {
  labels: {
    text: {
      fontSize: 12,
      fill: '#374151'
    }
  }
};

const SankeyChart: React.FC<SankeyChartProps> = ({ data }) => {
  return (
    <ResponsiveSankey
      data={data}
      margin={defaultMargin}
      align="justify"
      colors={{ scheme: 'category10' }}
      nodeOpacity={1}
      nodeHoverOthersOpacity={0.35}
      nodeThickness={18}
      nodeSpacing={24}
      nodeBorderWidth={0}
      nodeBorderRadius={3}
      linkOpacity={0.5}
      linkHoverOthersOpacity={0.1}
      linkContract={3}
      enableLinkGradient={true}
      labelPosition="outside"
      labelOrientation="horizontal"
      labelPadding={16}
      theme={defaultTheme}
    />
  );
};

export default SankeyChart;