import React, { useState } from 'react';
import { AlertCircle, X } from 'lucide-react';

interface HSCodeRequestProps {
  onSubmit: (code: string, description: string) => void;
  onCancel: () => void;
  isLimitReached: boolean;
  remainingCodes: number;
}

const HSCodeRequest: React.FC<HSCodeRequestProps> = ({
  onSubmit,
  onCancel,
  isLimitReached,
  remainingCodes
}) => {
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  const validateHSCode = (code: string) => {
    return /^\d{4}\.\d{2}$/.test(code);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateHSCode(code)) {
      setError('Please enter a valid HS code in the format XXXX.XX');
      return;
    }

    if (!description.trim()) {
      setError('Please enter a description');
      return;
    }

    onSubmit(code, description);
    setCode('');
    setDescription('');
  };

  if (isLimitReached) {
    return (
      <div className="rounded-md bg-yellow-50 p-4">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-yellow-400" />
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              You have reached your HS code allocation limit. Please contact support for an increase.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute top-0 right-0">
        <button
          onClick={onCancel}
          className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="max-w-2xl">
        <h3 className="text-lg font-medium text-gray-900">Request New HS Code</h3>
        <p className="mt-1 text-sm text-gray-500">
          Enter the HS code details below. You have {remainingCodes} request{remainingCodes !== 1 ? 's' : ''} remaining.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="hsCode" className="block text-sm font-medium text-gray-700">
                HS Code
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  id="hsCode"
                  placeholder="e.g., 8544.42"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
                <p className="mt-1 text-xs text-gray-500">Format: XXXX.XX</p>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <div className="mt-1">
                <textarea
                  id="description"
                  rows={3}
                  placeholder="Enter a detailed description of the HS code"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
              </div>
            </div>
          </div>

          {error && (
            <div className="rounded-md bg-red-50 p-4">
              <div className="flex">
                <AlertCircle className="h-5 w-5 text-red-400" />
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onCancel}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
            >
              Submit Request
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HSCodeRequest;