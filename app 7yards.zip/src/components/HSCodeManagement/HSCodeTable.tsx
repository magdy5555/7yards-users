import React from 'react';
import { Clock, CheckCircle, XCircle, RefreshCw, ArrowUpRight } from 'lucide-react';

interface HSCode {
  code: string;
  description: string;
  status: 'approved' | 'in_progress' | 'declined' | 'not_applied';
  lastUpdated: string;
}

interface HSCodeTableProps {
  codes: HSCode[];
  onResubmit: (code: string) => void;
  onSubmit: (code: string) => void;
}

const HSCodeTable: React.FC<HSCodeTableProps> = ({ codes, onResubmit, onSubmit }) => {
  const getStatusIcon = (status: HSCode['status']) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'in_progress':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'declined':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'not_applied':
        return <ArrowUpRight className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusText = (status: HSCode['status']) => {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'in_progress':
        return 'In Progress';
      case 'declined':
        return 'Declined';
      case 'not_applied':
        return 'Not Applied';
    }
  };

  const getStatusClass = (status: HSCode['status']) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      case 'not_applied':
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              HS Code
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Description
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Last Updated
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {codes.map((code) => (
            <tr key={code.code} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                  {code.code}
                </span>
              </td>
              <td className="px-6 py-4">
                <div className="text-sm text-gray-900">{code.description}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  {getStatusIcon(code.status)}
                  <span className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusClass(code.status)}`}>
                    {getStatusText(code.status)}
                  </span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {code.lastUpdated}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {code.status === 'declined' && (
                  <button
                    onClick={() => onResubmit(code.code)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                  >
                    <RefreshCw className="h-4 w-4 mr-1" />
                    Resubmit
                  </button>
                )}
                {code.status === 'not_applied' && (
                  <button
                    onClick={() => onSubmit(code.code)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200"
                  >
                    <ArrowUpRight className="h-4 w-4 mr-1" />
                    Submit
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default HSCodeTable;