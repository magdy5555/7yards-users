import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import HSCodeTable from './HSCodeManagement/HSCodeTable';
import HSCodeMetrics from './HSCodeManagement/HSCodeMetrics';
import HSCodeRequest from './HSCodeManagement/HSCodeRequest';

interface HSCodeSettingsProps {
  onBack: () => void;
}

const HSCodeSettings: React.FC<HSCodeSettingsProps> = ({ onBack }) => {
  // Mock data - replace with actual data source
  const [hsCodes] = useState([
    {
      code: '8544.42',
      description: 'Electric conductors and components',
      status: 'approved' as const,
      lastUpdated: '2024-03-15'
    },
    {
      code: '8501.10',
      description: 'Electric motors of an output <= 37.5 W',
      status: 'in_progress' as const,
      lastUpdated: '2024-03-14'
    },
    {
      code: '8536.90',
      description: 'Electrical apparatus for switching',
      status: 'declined' as const,
      lastUpdated: '2024-03-13'
    }
  ]);

  const metrics = {
    totalAllocation: 10,
    usedCodes: hsCodes.filter(code => code.status === 'approved').length,
    availableCodes: 10 - hsCodes.filter(code => code.status === 'approved').length
  };

  const handleResubmit = (code: string) => {
    // Implement resubmit logic
    console.log('Resubmitting code:', code);
  };

  const handleNewRequest = (code: string, description: string) => {
    // Implement new request logic
    console.log('New request:', { code, description });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={onBack}
        className="mb-6 inline-flex items-center text-sm text-gray-500 hover:text-gray-700"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Search
      </button>

      <div className="bg-white rounded-xl shadow-md">
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-900">Manage HS Codes</h1>
          <p className="mt-1 text-sm text-gray-500">
            View and manage your permitted HS codes for trade data access
          </p>
        </div>

        <div className="p-6 space-y-8">
          {/* Metrics */}
          <HSCodeMetrics {...metrics} />

          {/* HS Code Request Form */}
          <HSCodeRequest
            onSubmit={handleNewRequest}
            isLimitReached={metrics.availableCodes === 0}
            remainingCodes={metrics.availableCodes}
          />

          {/* HS Code Table */}
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">Current HS Codes</h2>
            <HSCodeTable
              codes={hsCodes}
              onResubmit={handleResubmit}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HSCodeSettings;