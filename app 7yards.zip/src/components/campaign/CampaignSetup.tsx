import React from 'react';
import { AlertCircle } from 'lucide-react';

interface CampaignSetupProps {
  data: {
    name: string;
    description?: string;
  };
  onChange: (data: any) => void;
  errors: Record<string, string>;
}

const CampaignSetup: React.FC<CampaignSetupProps> = ({ data, onChange, errors }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-gray-900">Campaign Setup</h3>
        <p className="mt-1 text-sm text-gray-500">
          Set up your campaign details and basic configuration.
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">
            Campaign Name *
          </label>
          <div className="mt-1">
            <input
              type="text"
              id="name"
              value={data.name}
              onChange={(e) => onChange({ ...data, name: e.target.value })}
              className={`block w-full rounded-md shadow-sm sm:text-sm ${
                errors.name
                  ? 'border-red-300 focus:border-red-500 focus:ring-red-500'
                  : 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500'
              }`}
            />
            {errors.name && (
              <p className="mt-2 text-sm text-red-600 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {errors.name}
              </p>
            )}
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <div className="mt-1">
            <textarea
              id="description"
              rows={4}
              value={data.description}
              onChange={(e) => onChange({ ...data, description: e.target.value })}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="Add a description for your campaign..."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CampaignSetup;